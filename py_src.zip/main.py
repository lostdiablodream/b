# Импортируем PyGame и операционку (для использования путей)
import pygame
import os
import csv
import random








# Основная функция игры
def main():
    # Инициализируем модули PyGame
    pygame.init()

    ##########################################################################################
    #####// определитесь с размерами игрового окна и создайте его с помощью кода
    ##########################################################################################

    # Устанавливаем ширину игрового окна - 800 пикселей
    SCREEN_WIDTH = 1900

    # Устанавливаем высоту игрового окна - 600 пикселей
    SCREEN_HEIGHT = 900

    # Создаем игровое окно с заданными размерами и сохраняем его в переменную screen
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

    # Устанавливаем заголовок окна
    pygame.display.set_caption('Игра-шмыгра. Тагил! Никитос летит..')

    # Определяем константы цветов в формате RGB
    WHITE = (255, 255, 255)  # Белый цвет
    BLACK = (0, 0, 0)  # Черный цвет
    RED = (255, 0, 0)  # Красный цвет
    GREEN = (0, 255, 0)  # Зелёный цвет
    SKYBLUE = (135, 206, 235)  # Цвет неба
    GINGER = (215, 125, 49)  # Рыжий оттенок

    ##########################################################################################

    # Прочие константы
    LEVEL_GRAPHICS = 21  # количество видов объектов уровня
    STROKI = 16  # строки
    STOLBTSY = 150  # столбцы
    LEVEL_GRAPHICS_SIZE = SCREEN_HEIGHT // STROKI  # размер игровых квадратов

    GRAVITATSIYA = 0.6

    NACHALNOE_POLOZHENIE_EKRANA = 0  # начальное положение экрана
    NACHALNOE_POLOZHENIE_FONA = 0  # начальное положение фона

    POROG_PROKRUTKI_EKRANA = 200  # порог прокрутки экрана 200

    ##########################################################################################
    ###// загружаем изображения
    ##########################################################################################
    FON = pygame.image.load('FON2.png')
    FON = pygame.transform.scale(FON, (screen.get_width(), screen.get_height()))

    ### создаём список ресурсов для управления расположением элементов уровня численной матрицей
    img_list = []
    for x in range(LEVEL_GRAPHICS):
        img = pygame.image.load(f'level_graphics/{x}.png')
        img = pygame.transform.scale(img, (LEVEL_GRAPHICS_SIZE, LEVEL_GRAPHICS_SIZE))
        img_list.append(img)

    # пиу-пиу графикс
    TAGIL_SHOT_GRAPHICS = pygame.image.load('tagil_shot_image/piu-piu.png').convert_alpha()

    # графика для запуска и окончания
    KNOPKA_ZAPUSKA_GRAPHICS = pygame.image.load('knopka_zapuska.png').convert_alpha()
    KNOPKA_VYKHODA_GRAPHICS = pygame.image.load('knopka_vyhoda.png').convert_alpha()

    # подгружаем картинки загрузки и окончания
    restart_img = pygame.image.load('knopka_zapuska.png').convert_alpha()
    end_img = pygame.image.load('knopka_vyhoda.png').convert_alpha()




    ##########################################################################################
    ###// поработайте с спрайтами (пока что можно использовать заглушки)
    ##########################################################################################


    # Класс батона
    # screen поправлен на surface в методе draw для отвязки от конкретного основного экрана
    class Button():
        def __init__(self, x, y, image, scale):
            width = image.get_width()
            height = image.get_height()
            self.image = pygame.transform.scale(image, (int(width * scale), int(height * scale)))
            self.rect = self.image.get_rect()
            self.rect.topleft = (x, y)
            self.clicked = False

        def draw(self, surface):
            action = False
            # определение где мыш
            pos = pygame.mouse.get_pos()
            # наведение мыш и клацев
            if self.rect.collidepoint(pos):
                if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                    action = True
                    self.clicked = True
            if pygame.mouse.get_pressed()[0] == 0:
                self.clicked = False
            # рисование батона
            surface.blit(self.image, (self.rect.x, self.rect.y))
            return action

    # создаем кнопки
    restart_button = Button(SCREEN_WIDTH // 2 - 100, SCREEN_HEIGHT // 2 - 50, restart_img, 2)
    end_button = Button(SCREEN_WIDTH // 2 - 128, SCREEN_HEIGHT // 2 - 128, end_img, 2)

    ##########################################################################################

    # Класс человечков посложнее

    class Soldier(pygame.sprite.Sprite):
        def __init__(self, char_type, x, y, scale, speed, ammo):
            pygame.sprite.Sprite.__init__(self)
            self.alive = True  # умер или не умер
            self.char_type = char_type  # тип человечка (игрок, враг, бабушка главного героя)
            self.speed = speed  # need for speed
            self.ammo = ammo  # текущее состояние гранат и пулемётов
            self.start_ammo = ammo  # количество гранат когда проснулся
            self.shoot_cooldown = 0  # время стрельбы
            self.health = 10  # здоровьице
            self.max_health = self.health  # силушка богатырская
            self.direction = 1  # налево пойдёшь, главного героя найдёшь, направо пойдёшь, пуля не догонит (-1;1)
            self.vel_y = 0  # вертикальная скорость
            self.jump = False  # статус прыжка
            self.in_air = True  # защита от начала прыжка до его окончания
            self.flip = False  # отражение изображения по вертикали (поворот персонажа)
            self.animation_list = []  # анимационный список
            self.frame_index = 0  # стартовый кадр в анимации
            self.action = 0  # стартовое действие
            self.update_time = pygame.time.get_ticks()  # опрос часов
            self.move_counter = 0  # счётчик движений
            self.vision = pygame.Rect(0, 0, 150, 20)  # где вас смогут засечь враги
            self.idling = False  # простой
            self.idling_counter = 0  # счётчик простоя

            # загрузка всех изображений для человечков
            animation_types = ['Idle', 'Run', 'Jump', 'Death', 'Shoot']
            for animation in animation_types:
                # очистить временный список изображений
                temp_list = []
                # счётчик число файлов в каталоге
                num_of_frames = len(os.listdir(f'sprites/{self.char_type}/{animation}'))
                for i in range(num_of_frames):
                    img = pygame.image.load(f'sprites/{self.char_type}/{animation}/image_{i}.png').convert_alpha()
                    img = pygame.transform.scale(img, (
                    int(img.get_width() * 0.5 * scale), int(img.get_height() * 0.5 * scale)))
                    temp_list.append(img)
                self.animation_list.append(temp_list)

            self.image = self.animation_list[self.action][self.frame_index]
            self.rect = self.image.get_rect()
            self.rect.center = (x, y)
            self.width = self.image.get_width()
            self.height = self.image.get_height()

        def update(self):
            # обновляем состояния
            self.update_animation()
            self.check_alive()

            if self.shoot_cooldown > 0:
                self.shoot_cooldown -= 1

        def move(self, moving_left, moving_right):
            # начальное обнуление переменных дельт
            NACHALNOE_POLOZHENIE_EKRANA = 0
            dx = 0
            dy = 0

            # обновляем значения изменения положения объекта по оси х
            if moving_left:
                dx = -self.speed
                self.flip = True
                self.direction = -1
            if moving_right:
                dx = self.speed
                self.flip = False
                self.direction = 1

            # прыжок
            if self.jump == True and self.in_air == False:
                self.vel_y = -15  # -10 норм прыжок, -25 - большой прыжок, - 100 - долгий прыжок за экран
                self.jump = False
                self.in_air = True

            # Гравитация
            self.vel_y += GRAVITATSIYA
            if self.vel_y > 10:
                self.vel_y
            dy += self.vel_y

            # Проверки на столкновения с объектами карты
            for tile in world.obstacle_list:
                # x-axis
                if tile[1].colliderect(self.rect.x + dx, self.rect.y, self.width, self.height):
                    dx = 0
                    # разворот адепта культа при столкновении со стеной
                    if self.char_type == 'enemy':
                        self.direction *= -1
                        self.move_counter = 0
                # y-axys
                if tile[1].colliderect(self.rect.x, self.rect.y + dy, self.width, self.height):
                    # для прыжка
                    if self.vel_y < 0:
                        self.vel_y = 0
                        dy = tile[1].bottom - self.rect.top
                    # для приземления
                    elif self.vel_y >= 0:
                        self.vel_y = 0
                        self.in_air = False
                        dy = tile[1].top - self.rect.bottom

            # Проверка чтобы не уйти за левую границу экрана
            if self.char_type == 'player':
                if self.rect.left + dx < 0:
                    dx = 0

            # Обновляем положение объекта
            self.rect.x += dx
            self.rect.y += dy

            # Скролл экрана
            if self.char_type == 'player':
                if (self.rect.right > SCREEN_WIDTH - POROG_PROKRUTKI_EKRANA and NACHALNOE_POLOZHENIE_FONA < (world.level_length * LEVEL_GRAPHICS_SIZE) - SCREEN_WIDTH) or (self.rect.left < POROG_PROKRUTKI_EKRANA and NACHALNOE_POLOZHENIE_FONA > abs(dx)):
                    self.rect.x -= dx
                    NACHALNOE_POLOZHENIE_EKRANA = -dx

            return NACHALNOE_POLOZHENIE_EKRANA

        # Стрельба. Добавление пиу-пиу в группу оружия и трата ammo
        def shoot(self):
            if self.shoot_cooldown == 0 and self.ammo > 0:
                self.shoot_cooldown = 20
                piupiu = Piupiu(self.rect.centerx + (0.75 * self.rect.size[0] * self.direction), self.rect.centery, self.direction)
                piupiu_group.add(piupiu)
                self.ammo -= 1
                # Если это враг, вернуться к покою после завершения анимации стрельбы
                if self.char_type == 'enemy' and self.action == 4 and self.frame_index >= len(self.animation_list[4]) - 1:
                    self.update_action(0)

        # алгоритм движения адептов культа
        def adept(self):
            if self.alive and player.alive:
                if self.idling == False and random.randint(1, 200) == 1:
                    self.update_action(0)  # Простой в случайный момент времени
                    self.idling = True
                    self.idling_counter = 50
                # Проверка наличия игрока в области видимости бота
                if self.vision.colliderect(player.rect):
                    # Прекращение патрулирования и разворот к игроку
                    self.update_action(4)
                    self.shoot()
                else:
                    if self.idling == False:
                        # Патрулирование
                        if self.direction == 1:
                            adept_moving_right = True
                        else:
                            adept_moving_right = False
                        adept_moving_left = not adept_moving_right
                        self.move(adept_moving_left, adept_moving_right)
                        self.update_action(1)
                        self.move_counter += 1
                        self.vision.center = (self.rect.centerx + 75 * self.direction, self.rect.centery)
                        # Разворот при окончании области
                        if self.move_counter > LEVEL_GRAPHICS_SIZE:
                            self.direction *= -1
                            self.move_counter *= -1
                    else:  # Уменьщение времени простоя
                        self.idling_counter -= 1
                        if self.idling_counter <= 0:
                            self.idling = False

            self.rect.x += NACHALNOE_POLOZHENIE_EKRANA

        def update_animation(self):
            # обновление кадра
            ANIMATION_COOLDOWN = 200  # задержка смены кадра в миллисекундах
            self.image = self.animation_list[self.action][self.frame_index]
            if pygame.time.get_ticks() - self.update_time > ANIMATION_COOLDOWN:
                self.update_time = pygame.time.get_ticks()
                self.frame_index += 1
            # Если не анимация смерти, то идет по кругу
            if self.frame_index >= len(self.animation_list[self.action]):
                if self.action == 3:
                    self.frame_index = len(self.animation_list[self.action]) - 1
                else:
                    self.frame_index = 0

        def update_action(self, new_action):
            # Смена действия
            if new_action != self.action:
                self.action = new_action
                # Смена анимации одного действия на другое
                self.frame_index = 0
                self.update_time = pygame.time.get_ticks()

        # проверка состояния жив/мертв
        def check_alive(self):
            if self.health <= 0:
                self.health = 0
                self.speed = 0
                self.alive = False
                self.update_action(3)

        def draw(self):
            screen.blit(pygame.transform.flip(self.image, self.flip, False), self.rect)

    ##########################################################################################
    ###// поработайте с объектом сцены
    ##########################################################################################

    # Класс объекта сцены
    class Scene:

        # Метод инициализации сцены
        def __init__(self, width, height):
            # ширина сцены
            self.width = width

            # длина сцены
            self.height = height

            # Фон
            self.background = pygame.Surface((width, height))

            # Заливаем фон
            self.background.fill(SKYBLUE)  # Белым цветом

        # Метод отрисовки сцены
        def draw(self, surface):
            # Отрисовываем фон на переданной поверхности
            surface.blit(self.background, (0, 0))

    ##########################################################################################

    # сцена посложнее

    # Создание уровня

    class World():
        def __init__(self):
            self.obstacle_list = []
            self.finish_block = None
            self.finish_img = None
            self.finish_block_orig_x = None
            self.level_length = 0

        def process_data(self, data):
            self.level_length = len(data[0])
            # обработка числовых значений CSV
            for y, row in enumerate(data):
                for x, tile in enumerate(row):
                    if tile >= 0:
                        print(f"[DEBUG] tile = {tile}, img_list size = {len(img_list)}")
                        img = img_list[tile]
                        img_rect = img.get_rect()
                        img_rect.x = x * LEVEL_GRAPHICS_SIZE
                        img_rect.y = y * LEVEL_GRAPHICS_SIZE
                        tile_data = (img, img_rect)
                        if tile >= 0 and tile <= 2:  # физические препятствия(пол, стены)
                            self.obstacle_list.append(tile_data)
                        elif tile == 15:  # начальное положение Никитоса
                            player = Soldier('player', x * LEVEL_GRAPHICS_SIZE, y * LEVEL_GRAPHICS_SIZE, 2.65, 5, 75)
                            health_bar = HealthBar(15, 70, player.health, player.health)
                        elif tile == 16:  # начальное положение адепта культа
                            enemy = Soldier('enemy', x * LEVEL_GRAPHICS_SIZE, y * LEVEL_GRAPHICS_SIZE, 3.65, 2, 20)
                            enemy_group.add(enemy)
                        elif tile == 17:  # финишный блок
                            self.finish_block = img_rect.copy()  # Сохраняем координаты финишного блока
                            # Также добавим его в список для отрисовки
                            self.finish_img = img
                            self.finish_block_orig_x = x * LEVEL_GRAPHICS_SIZE

            return player, health_bar

        def draw(self):
            for tile in self.obstacle_list:
                tile[1].x += NACHALNOE_POLOZHENIE_EKRANA
                screen.blit(tile[0], tile[1])

#                if self.finish_block:
#                    self.finish_block.x += NACHALNOE_POLOZHENIE_EKRANA
#                    screen.blit(self.finish_img, self.finish_block)

#        def update_finish_block_position(self):
#            if self.finish_block:
#                # Вычисляем актуальную позицию на экране с учетом прокрутки
#                self.finish_block.x = self.finish_block_orig_x - NACHALNOE_POLOZHENIE_FONA

        # Отрисовываем финишный блок, если он существует
            if self.finish_block and self.finish_img:
            # Вычисляем актуальную позицию на экране относительно прокрутки
                finish_x = self.finish_block_orig_x - NACHALNOE_POLOZHENIE_FONA

            # Временно устанавливаем позицию для отрисовки
                self.finish_block.x = finish_x

            # Отрисовываем финишный блок
                screen.blit(self.finish_img, self.finish_block)


        def update(self):
            self.rect.x += NACHALNOE_POLOZHENIE_EKRANA

    # описание полосы здоровья
    class HealthBar():
        def __init__(self, x, y, health, max_health):
            self.x = x
            self.y = y
            self.health = health
            self.max_health = max_health

        def draw(self, health):
            # обновление величины здоровья
            self.health = health
            # отрисовка здоровьица
            ratio = self.health / self.max_health
            pygame.draw.rect(screen, BLACK, (self.x - 2, self.y - 2, 504, 54))
            pygame.draw.rect(screen, GINGER, (self.x, self.y, 500, 50))
            pygame.draw.rect(screen, GREEN, (self.x, self.y, 500 * ratio, 50))

    # пиу-пиу класс
    class Piupiu(pygame.sprite.Sprite):
        def __init__(self, x, y, direction):
            pygame.sprite.Sprite.__init__(self)
            self.speed = 10
            self.image = TAGIL_SHOT_GRAPHICS
            self.rect = self.image.get_rect()
            self.rect.center = (x, y)
            self.direction = direction

        def update(self):
            # движение снаряда
            self.rect.x += (self.direction * self.speed) + NACHALNOE_POLOZHENIE_EKRANA
            # вытираем снаряд, если выходит за рамки экрана
            if self.rect.right < 0 or self.rect.left > SCREEN_WIDTH:
                self.kill()
            # вытираем снаряд, если сталкивается с физическим объектом
            for tile in world.obstacle_list:
                if tile[1].colliderect(self.rect):
                    self.kill()

            # вытираем снаряд, если сталкивается с персонажем. У персонажа снижаем здоровье
            if pygame.sprite.spritecollide(player, piupiu_group, False):
                if player.alive:
                    player.health -= 1
                    self.kill()
            for enemy in enemy_group:
                if pygame.sprite.spritecollide(enemy, piupiu_group, False):
                    if enemy.alive:
                        enemy.health -= 25
                        self.kill()

    # Для массовых объектов создаем группы
    enemy_group = pygame.sprite.Group()
    piupiu_group = pygame.sprite.Group()


    world_data = []
    for row in range(STROKI):
        r = [-1] * STOLBTSY
        world_data.append(r)
    # загрузка схемы уровня и отрисовка
    with open(f'UROVEN.csv', newline='') as csvfile:
        reader = csv.reader(csvfile, delimiter=',')
        for x, row in enumerate(reader):
            for y, tile in enumerate(row):
                world_data[x][y] = int(tile)
    world = World()
    player, health_bar = world.process_data(world_data)

    # отрисовывка фона
    def OTRISOVKA_FONA():
        screen.blit(FON, [0, 0])

    # приводим уровень в начальное состояние
    def reset_level():
        enemy_group.empty()
        piupiu_group.empty()
        data = []
        for row in range(STROKI):
            r = [-1] * STOLBTSY
            data.append(r)
        return data


    # Создаем счётчик опорного времени для контроля частоты кадров
    clock = pygame.time.Clock()

    # Устанавливаем количество кадров в секунду
    FPS = 60



    # Основной игровой цикл
#    running = True
#    while running:
        # Обработка событий
#        for event in pygame.event.get():
            # Выход из игры при закрытии окна
#            if event.type == pygame.QUIT:
#                running = False

            ##########################################################################################
            ###// настройте управление
            ##########################################################################################

            # Обработка нажатий клавиш
#            if event.type == pygame.KEYDOWN:

                # Движение влево
#                if event.key == pygame.K_a:
#                    player.speed_x = -5

                # Движение вправо
#                if event.key == pygame.K_d:
#                    player.speed_x = 5

                # Движение вверх
#                if event.key == pygame.K_w:
#                    player.speed_y = -5

                # Движение вниз
#                if event.key == pygame.K_s:
#                    player.speed_y = 5

            # Остановка движения при отпускании клавиш
#            if event.type == pygame.KEYUP:

                # Остановка горизонтального движения
#                if event.key in [pygame.K_a, pygame.K_d]:
#                    player.speed_x = 0

                # Остановка вертикального движения
#                if event.key in [pygame.K_w, pygame.K_s]:
#                    player.speed_y = 0

        ##########################################################################################

        # Обновление состояния игрока
#        player_group.update()

        # Отрисовка сцены
#        scene.draw(screen)

        # Отрисовка игрока
#        player_group.draw(screen)

        # Обновление экрана
#        pygame.display.flip()

        # Контроль частоты кадров
#        clock.tick(FPS)

    # Завершение работы Pygame
#    pygame.quit()

    # стартовые значения переменных состояния
    moving_left = False  # движения влево не происходит
    moving_right = False  # движения вправо не происходит
    shoot = False


    run = True
    while run:
        clock.tick(FPS)
        #world.update_finish_block_position()
        # цикличная отрисовка фона
        OTRISOVKA_FONA()
        # отрисовка уровня
        world.draw()
        # отрисовка полосы здоровья
        health_bar.draw(player.health)
        # отрисовка патронов у игрока
        for x in range(player.ammo):
            screen.blit(TAGIL_SHOT_GRAPHICS, (10 + (x * 20), 40))
        #обновление и отрисовка игрока
        player.update()
        player.draw()

        #обновляем состояния всех ботов
        for enemy in enemy_group:
            enemy.adept()
            enemy.update()
            enemy.draw()

        #обновляем и отрисовываем остальные группы
        piupiu_group.update()

        piupiu_group.draw(screen)





        #обновление действий игрока, пока он жив
        if player.alive and player.rect.top<screen.get_height():
            #Стрельба
            if shoot:
                player.shoot()
            #Прыжок
            if player.in_air:
                player.update_action(2)
            #Движение
            elif moving_left or moving_right:
                player.update_action(1)
            #Простой
            else:
                player.update_action(0)
            NACHALNOE_POLOZHENIE_EKRANA = player.move(moving_left, moving_right)
            NACHALNOE_POLOZHENIE_FONA -= NACHALNOE_POLOZHENIE_EKRANA
        else:
            player.alive = False
            screen.fill((255, 255, 255))
            font = pygame.font.SysFont('Arial', 70)
            game_over_text = font.render('Вы проиграли!', True, (255, 0, 0))
            screen.blit(game_over_text,
                        (SCREEN_WIDTH // 2 - game_over_text.get_width() // 2, SCREEN_HEIGHT // 3 - 100))
            if restart_button.draw(screen):
            #Если игрок мертв - начинаем заново
                NACHALNOE_POLOZHENIE_EKRANA = 0
                NACHALNOE_POLOZHENIE_FONA = 0
                world_data = reset_level()
                # load in level data and create world
                with open(f'UROVEN.csv', newline='') as csvfile:
                    reader = csv.reader(csvfile, delimiter=',')
                    for x, row in enumerate(reader):
                        for y, tile in enumerate(row):
                            world_data[x][y] = int(tile)
                world = World()
                player, health_bar = world.process_data(world_data)

        #обработка событий с клавиатуры
        for event in pygame.event.get():
            #Закрытие окна
            if event.type == pygame.QUIT:
                run = False
            #обработка клавиш WAD, пробел и esc
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_a:
                    moving_left = True
                if event.key == pygame.K_d:
                    moving_right = True
                if event.key == pygame.K_SPACE:
                    shoot = True
                if event.key == pygame.K_w:
                    player.jump = True
                if event.key == pygame.K_ESCAPE:
                    run = False

            #обработка отпускания клавиш AD и пробел
            if event.type == pygame.KEYUP:
                if event.key == pygame.K_a:
                    moving_left = False
                if event.key == pygame.K_d:
                    moving_right = False
                if event.key == pygame.K_SPACE:
                    shoot = False

        #Условие завершения игры при прохождении уровня
#        if player.rect.right > SCREEN_WIDTH:
                # Заливаем фон белым цветом
#            screen.fill((255,255,255))
#            player.alive = False
        if player.rect.bottom > SCREEN_HEIGHT:
            # Если упал - проигрыш
            player.alive = False
            screen.fill((255, 255, 255))
            font = pygame.font.SysFont('Arial', 70)
            game_over_text = font.render('Вы проиграли!', True, (255, 0, 0))
            screen.blit(game_over_text,
                        (SCREEN_WIDTH // 2 - game_over_text.get_width() // 2, SCREEN_HEIGHT // 3 - 100))
            if restart_button.draw(screen):
                # Перезапуск уровня
                NACHALNOE_POLOZHENIE_EKRANA = 0
                NACHALNOE_POLOZHENIE_FONA = 0
                world_data = reset_level()
                # Загрузка уровня заново
                with open(f'UROVEN.csv', newline='') as csvfile:
                    reader = csv.reader(csvfile, delimiter=',')
                    for x, row in enumerate(reader):
                        for y, tile in enumerate(row):
                            world_data[x][y] = int(tile)
                world = World()
                player, health_bar = world.process_data(world_data)
        # Проверка, достиг ли игрок финишного блока
        elif world.finish_block and player.rect.colliderect(world.finish_block):
            screen.fill((255, 255, 255))
            font = pygame.font.SysFont('Arial', 70)
            victory_text = font.render('Уровень пройден! Вы победитель!', True, (0, 128, 0))
            screen.blit(victory_text, (SCREEN_WIDTH // 2 - victory_text.get_width() // 2, SCREEN_HEIGHT // 3 - 100))

            if end_button.draw(screen):
                run = False
            pygame.display.update()
        # отрисовываем фон

            #run = False


        #Обновление состояния
        pygame.display.update()
    pygame.quit()
# Точка входа в программу
if __name__ == "__main__":
    # Запуск основной функции игры
    main()